﻿using Microsoft.AspNetCore.SignalR;

namespace OnlineClassRooms.Hubs
{
    public class ClassHub:Hub
    {
        public async Task AddStudent(string userName)
        {
            await Clients.All.SendAsync("ReceiveStudent", userName);
        }

        public async Task SendMessage(string user,string message)
        {
            await Clients.All.SendAsync("ReceiveMessage",user, message);
        }

        public async Task RaisedHand(string userName)
        {
            await Clients.All.SendAsync("Notification", userName);
        }

        public async Task UnRaisedHand(string userName)
        {
            await Clients.All.SendAsync("NotificationDelete", userName);
        }
       
    }
}
